//The following code will be given to all HTML files

$(document).ready(function() { //Fade in animation
$(".logo").fadeIn();
$("nav").fadeIn();
$("img").fadeIn();
$("#form").fadeIn();
$("#timebox").fadeIn();
$("h1").slideDown();
$("h2").slideDown();
$("button").animate({opacity: "1"});

});




